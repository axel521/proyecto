<?php
// Configuración de la conexión
$host = 'localhost';
$db = 'sena';
$user = 'root';
$pass = '';

// Conexión
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}