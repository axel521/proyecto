<?php
include "db.php";

// Recibir datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['usuario'];
    $tipoDocumento = $_POST['tipoDocumento'];
    $documento = $_POST['documento'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_BCRYPT);
    $correo = $_POST['correo'];
    $rol = $_POST['rol'];

    // Consulta de inserción
    $sql = "INSERT INTO usuarios (Nombre, Tipo_Documento, Documento, Contraseña, Correo, Rol)
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $nombre, $tipoDocumento, $documento, $contraseña, $correo, $rol);

    if ($stmt->execute()) {
        header("Location: ../InicioUsuario.html");
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
$conn->close();
?>