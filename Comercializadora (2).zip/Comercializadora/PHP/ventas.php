<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario Ventas</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #f5f6fa;
            --accent-color: #2ecc71;
            --text-color: #2c3e50;
            --sidebar-width: 250px;
            --sidebar-bg: #39465c;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

    /* Barra lateral mejorada */
    .sidebar {
        width: 280px;
        background: linear-gradient(180deg, #394867 0%, #212A3E 100%);
        color: white;
        padding: 20px;
        position: fixed;
        height: 100vh;
        left: 0;
        top: 0;
        animation: slideIn 0.5s ease-out;
        z-index: 1000;
        position: relative; 
        display: flex;
        flex-direction: column;
    }
    .logout-btn:hover {
        background-color: #c0392b !important;
    }
    .logo {
        text-align: center;
        padding: 20px 0;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        margin-bottom: 30px;
    }

    .logo img {
        width: 60px;
        transition: transform 0.3s ease;
    }

    .logo img:hover {
        transform: scale(1.1);
    }

    .menu-item {
        display: flex;
        align-items: center;
        padding: 15px;
        margin-bottom: 10px;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        transition: all 0.3s ease;
        font-size: 16px;
    }

    .menu-item:hover {
        background-color: rgba(255,255,255,0.1);
        transform: translateX(10px);
    }

    .menu-item i {
        margin-right: 15px;
        font-size: 20px;
    }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 2rem;
            background-color: var(--secondary-color);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: var(--shadow);
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h1 {
            color: var(--primary-color);
            margin-bottom: 2rem;
            text-align: center;
            font-size: 2.5rem;
            position: relative;
        }

        h1::after {
            content: '';
            display: block;
            width: 100px;
            height: 4px;
            background: var(--accent-color);
            margin: 10px auto;
            border-radius: 2px;
        }

        h2 {
            color: var(--text-color);
            margin: 2rem 0;
            text-align: center;
        }

        /* Buttons Container */
        .buttons-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin: 2rem 0;
        }

        .buttons-container form {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
        }

        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #357abd;
            transform: translateY(-2px);
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 2rem;
            background: white;
            box-shadow: var(--shadow);
            border-radius: 10px;
            overflow: hidden;
        }

        thead {
            background-color: var(--primary-color);
            color: white;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        tbody tr {
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.01);
        }

        /* Error Message */
        .error-message {
            text-align: center;
            color: #e74c3c;
            padding: 1rem;
            background: #fdf0ef;
            border-radius: 8px;
            margin: 1rem 0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 1000;
            }

            .main-content {
                margin-left: 0;
                padding: 1rem;
            }

            .container {
                padding: 1rem;
            }

            .buttons-container form {
                flex-direction: column;
            }

            table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
    <div class="logo">
        <img src="sena-logo.png" alt="SENA">
    </div>
    <a href="../Vendedor.php" class="menu-item">✉️ Recibidos</a>
    <a href="reportes.php" class="menu-item">📊 Reportes</a>
    <a href="ventas.php" class="menu-item">💰 Ventas</a>
    <a href="../InicioUsuario.html" class="menu-item logout-btn" style="margin-top: auto; background-color: #e74c3c; position: absolute; bottom: 20px; left: 20px; right: 20px;">
            <i class="fas fa-sign-out-alt"></i>
            Cerrar Sesión
    </a>
</div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <h1>Inventario Ventas</h1>

            <!-- Botones para filtrar por categoría -->
            <div class="buttons-container">
                <form method="POST" action="">
                    <button type="submit" name="categoria" value="Agricultura">
                        <i class="fas fa-seedling"></i> Agricultura
                    </button>
                    <button type="submit" name="categoria" value="R_Naturales">
                        <i class="fas fa-tree"></i> R. Naturales
                    </button>
                    <button type="submit" name="categoria" value="Aves">
                        <i class="fas fa-dove"></i> Aves
                    </button>
                    <button type="submit" name="categoria" value="Ovinos">
                        <i class="fas fa-sheep"></i> Ovinos
                    </button>
                    <button type="submit" name="categoria" value="Caprino">
                        <i class="fas fa-horse"></i> Caprinos
                    </button>
                    <button type="submit" name="categoria" value="Porcinos">
                        <i class="fas fa-pig"></i> Porcinos
                    </button>
                    <button type="submit" name="categoria" value="Conejos">
                        <i class="fas fa-rabbit"></i> Conejos
                    </button>
                    <button type="submit" name="categoria" value="Tecnologia">
                        <i class="fas fa-laptop"></i> Tecnología
                    </button>
                    <button type="submit" name="categoria" value="Ganaderia">
                        <i class="fas fa-cow"></i> Ganadería
                    </button>
                </form>
</div>

<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sena";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar selección de categoría
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['categoria'])) {
    $categoria = $_POST['categoria'];

    // Consulta a la tabla de recibos para filtrar por producto (categoría)
    $sql = "SELECT * FROM recibos WHERE producto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $categoria);
    $stmt->execute();
    $result = $stmt->get_result();

    // Mostrar reporte
    if ($result->num_rows > 0) {
        echo "<h2>Reporte de $categoria</h2>";
        echo "<table>";
        echo "<thead>
                <tr>
                    <th>ID</th>
                    <th>Código</th>
                    <th>Fecha</th>
                    <th>Entregado a</th>
                    <th>Producto</th>
                    <th>Recibido de</th>
                    <th>Cantidad</th>
                    <th>P. Unitario (COP)</th>
                    <th>Valores (COP)</th>
                </tr>
              </thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            $p_unit_cop = number_format($row['p_unit'], 2, ',', '.') . " COP";
            $valores_cop = number_format($row['valores'], 2, ',', '.') . " COP";
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['codigo']}</td>
                    <td>{$row['fecha']}</td>
                    <td>{$row['entregado_a']}</td>
                    <td>{$row['producto']}</td>
                    <td>{$row['recibido_de']}</td>
                    <td>{$row['cantidad']}</td>
                    <td>$p_unit_cop</td>
                    <td>$valores_cop</td>
                  </tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p style='color: red;'>No se encontraron registros para la categoría '$categoria'.</p>";
    }
    $stmt->close();
}

$conn->close();
?>

</body>
</html>
