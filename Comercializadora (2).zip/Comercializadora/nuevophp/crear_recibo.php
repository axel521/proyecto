<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $admin_id = $_POST['admin_id'];
    $vendedor_id = $_POST['vendedor_id'];
    $productos = $_POST['productos']; // Un array de productos (nombre, cantidad, precio)

    try {
        // Verificar si el admin_id existe en la tabla usuarios
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE id = ?");
        $stmt->execute([$admin_id]);
        $admin_exists = $stmt->fetchColumn();

        if (!$admin_exists) {
            throw new Exception("El admin_id no existe en la base de datos.");
        }

        // Verificar si el vendedor_id existe en la tabla usuarios
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE id = ?");
        $stmt->execute([$vendedor_id]);
        $vendedor_exists = $stmt->fetchColumn();

        if (!$vendedor_exists) {
            throw new Exception("El vendedor_id no existe en la base de datos.");
        }

        // Insertar el recibo
        $stmt = $pdo->prepare("INSERT INTO recibos (admin_id, vendedor_id) VALUES (?, ?)");
        $stmt->execute([$admin_id, $vendedor_id]);
        $recibo_id = $pdo->lastInsertId(); // Obtener el ID del recibo creado

        // Insertar los productos en el recibo
        foreach ($productos as $producto) {
            $nombre = $producto['nombre'];
            $unidad = $producto['unidad'];
            $cantidad = $producto['cantidad'];
            $precio_unitario = $producto['precio_unitario'];
            $total = $cantidad * $precio_unitario;

            $stmt_producto = $pdo->prepare("INSERT INTO productos (recibo_id, nombre, unidad, cantidad, precio_unitario, total) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt_producto->execute([$recibo_id, $nombre, $unidad, $cantidad, $precio_unitario, $total]);
        }

        header("location: index.html");
    } catch (Exception $e) {
        echo "Error al crear recibo: " . $e->getMessage();
    }
}
?>
