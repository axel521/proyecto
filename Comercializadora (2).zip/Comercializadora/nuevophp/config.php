<?php
$host = 'localhost'; // Cambia esto si es necesario
$dbname = 'sena2';
$username = 'root'; // Usuario de MySQL
$password = ''; // Contraseña de MySQL (si es necesario)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
}
?>
