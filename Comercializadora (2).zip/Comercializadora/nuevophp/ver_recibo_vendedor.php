<?php
include('config.php');

// Suponiendo que el vendedor tiene un ID (por ejemplo, 2)
$vendedor_id = 2; // Debes obtener este valor dinámicamente, por ejemplo, mediante sesión

// Obtener los recibos del vendedor (aquí puedes ajustar la lógica para que el vendedor vea sólo los recibos que le pertenecen)
$stmt = $pdo->prepare("SELECT r.id AS recibo_id, r.fecha_creacion, p.id AS producto_id, p.nombre, p.cantidad, p.precio_unitario, p.total, er.recibido
                        FROM recibos r
                        JOIN productos p ON p.recibo_id = r.id
                        LEFT JOIN estado_recibo er ON er.producto_id = p.id
                        WHERE r.vendedor_id = ?");
$stmt->execute([$vendedor_id]);
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Recibos</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2ecc71;
            --secondary-color: #27ae60;
            --background-color: #f5f6fa;
            --sidebar-width: 250px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            display: flex;
            background-color: var(--background-color);
        }

        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            background: white;
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            transition: transform 0.3s ease;
            
        }

        .logo {
            text-align: center;
            margin-bottom: 40px;
            padding: 20px;
        }

        .logo img {
            max-width: 120px;
            transition: transform 0.3s ease;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px;
            color: #333;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }

        .menu-item i {
            margin-right: 15px;
            font-size: 1.2em;
        }

        .menu-item:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateX(10px);
        }

        .logout-btn {
            background-color: #e74c3c;
            color: white;
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
        }

        .logout-btn:hover {
            background-color: #c0392b;
        }
        main {
            margin-left: var(--sidebar-width);
            padding: 40px;
            width: calc(100% - var(--sidebar-width));
        }

        h1 {
            color: #2c3e50;
            margin-bottom: 30px;
            font-size: 2.2em;
        }

        .producto {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transform: translateY(0);
            transition: all 0.3s ease;
        }

        .producto:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .producto input[type="checkbox"] {
            margin-right: 15px;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        button[type="submit"] {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            margin-top: 20px;
            transition: all 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: var(--secondary-color);
            transform: scale(1.05);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .producto {
            animation: fadeIn 0.5s ease forwards;
            opacity: 0;
        }

        .producto:nth-child(1) { animation-delay: 0.1s; }
        .producto:nth-child(2) { animation-delay: 0.2s; }
        .producto:nth-child(3) { animation-delay: 0.3s; }
    </style>
</head>
<body>
    <?php
    include('config.php');
    $vendedor_id = 2;
    $stmt = $pdo->prepare("SELECT r.id AS recibo_id, r.fecha_creacion, p.id AS producto_id, p.nombre, p.cantidad, p.precio_unitario, p.total, er.recibido
                            FROM recibos r
                            JOIN productos p ON p.recibo_id = r.id
                            LEFT JOIN estado_recibo er ON er.producto_id = p.id
                            WHERE r.vendedor_id = ?");
    $stmt->execute([$vendedor_id]);
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="sidebar">
        <div class="logo">
            <img src="sena-logo.png" alt="SENA">
        </div>
        <a href="../Vendedor.php" class="menu-item">
            <i class="fas fa-inbox"></i>
            Recibidos
        </a>
        <a href="../InicioUsuario.html" class="menu-item logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            Cerrar Sesión
        </a>
    </div>

    <main>
        <h1><i class="fas fa-receipt"></i> Gestión de Recibos</h1>
        
        <?php if (empty($productos)): ?>
            <div class="producto">
                <p>No hay recibos disponibles para este vendedor.</p>
            </div>
        <?php else: ?>
            <form id="form-recibo">
                <?php foreach ($productos as $producto): ?>
                    <div class="producto">
                        <input type="checkbox" name="productos[<?php echo $producto['producto_id']; ?>]" 
                               value="1" <?php echo ($producto['recibido'] == 1) ? 'checked' : ''; ?>>
                        <div>
                            <strong><?php echo $producto['nombre']; ?></strong>
                            <p>Cantidad: <?php echo $producto['cantidad']; ?> unidades</p>
                            <p>Total: $<?php echo number_format($producto['total'], 2); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>

                <button type="submit">
                    <i class="fas fa-paper-plane"></i> Enviar al Administrador
                </button>
            </form>
        <?php endif; ?>
    </main>

    <script>
        document.getElementById('form-recibo').addEventListener('submit', function(e) {
            e.preventDefault();
            const button = this.querySelector('button[type="submit"]');
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';

            const formData = new FormData(this);

            fetch('marcar_recibo.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar al Administrador';
            })
            .catch(error => {
                console.error('Error:', error);
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar al Administrador';
                alert('Hubo un error al procesar tu solicitud.');
            });
        });
    </script>
</body>
</html>