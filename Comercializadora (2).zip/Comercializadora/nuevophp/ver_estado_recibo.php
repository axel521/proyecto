<?php
include('config.php');

// Suponiendo que el administrador tiene un ID (por ejemplo, 1)
$admin_id = 1; // Este valor lo debes obtener dinámicamente, por ejemplo, mediante sesión

// Obtener los recibos para el administrador
$stmt = $pdo->prepare("SELECT r.id AS recibo_id, p.id AS producto_id, p.nombre, p.cantidad, p.precio_unitario, p.total, er.recibido
                        FROM recibos r
                        JOIN productos p ON p.recibo_id = r.id
                        LEFT JOIN estado_recibo er ON er.producto_id = p.id
                        WHERE r.admin_id = ?");
$stmt->execute([$admin_id]);
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($productos)) {
    echo "No hay recibos para este administrador.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrativo - Recibos</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --background-color: #f5f6fa;
            --sidebar-width: 250px;
            --table-border-color: #e1e1e1;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            display: flex;
            background-color: var(--background-color);
        }

        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            background: white;
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            transition: transform 0.3s ease;
        }

        .logo {
            text-align: center;
            margin-bottom: 40px;
            padding: 20px;
        }

        .logo img {
            max-width: 120px;
            transition: transform 0.3s ease;
        }

        .logo img:hover {
            transform: scale(1.1);
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px;
            color: #333;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }

        .menu-item i {
            margin-right: 15px;
            font-size: 1.2em;
        }

        .menu-item:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateX(10px);
        }

        .logout-btn {
            background-color: #e74c3c;
            color: white;
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
        }

        .logout-btn:hover {
            background-color: #c0392b;
        }

        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px;
            width: calc(100% - var(--sidebar-width));
        }

        .container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 30px;
            animation: slideIn 0.5s ease;
        }

        h1 {
            color: #2c3e50;
            margin-bottom: 30px;
            font-size: 2.2em;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .table-container {
            overflow-x: auto;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }

        thead {
            background-color: var(--primary-color);
            color: white;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--table-border-color);
        }

        th {
            font-weight: 600;
        }

        tbody tr {
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #2ecc71;
        }

        input:disabled + .slider {
            opacity: 0.6;
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        tr {
            animation: fadeIn 0.5s ease forwards;
            opacity: 0;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        tbody tr:nth-child(1) { animation-delay: 0.1s; }
        tbody tr:nth-child(2) { animation-delay: 0.2s; }
        tbody tr:nth-child(3) { animation-delay: 0.3s; }
        tbody tr:nth-child(4) { animation-delay: 0.4s; }
        tbody tr:nth-child(5) { animation-delay: 0.5s; }
    </style>
</head>
<body>
    <?php
    include('config.php');
    $admin_id = 1;
    $stmt = $pdo->prepare("SELECT r.id AS recibo_id, p.id AS producto_id, p.nombre, p.cantidad, p.precio_unitario, p.total, er.recibido
                            FROM recibos r
                            JOIN productos p ON p.recibo_id = r.id
                            LEFT JOIN estado_recibo er ON er.producto_id = p.id
                            WHERE r.admin_id = ?");
    $stmt->execute([$admin_id]);
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="sidebar">
        <div class="logo">
            <img src="sena-logo.png" alt="SENA">
        </div>
        <a href="../Admin_pagina.html" class="menu-item">
            <i class="fas fa-inbox"></i>
            Recibidos
        </a>
        <a href="index.html" class="menu-item">
            <i class="fas fa-chart-line"></i>
            Crear Recibo
        </a>
        <a href="../InicioUsuario.html" class="menu-item logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            Cerrar Sesión
        </a>
    </div>

    <div class="main-content">
        <div class="container">
            <h1>
                <i class="fas fa-clipboard-list"></i>
                Panel de Recibos
            </h1>

            <?php if (empty($productos)): ?>
                <div class="empty-state">
                    <p>No hay recibos disponibles para mostrar.</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Total</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($productos as $producto): ?>
                                <tr>
                                    <td>
                                        <i class="fas fa-box"></i>
                                        <?php echo $producto['nombre']; ?>
                                    </td>
                                    <td>
                                        <i class="fas fa-cubes"></i>
                                        <?php echo $producto['cantidad']; ?>
                                    </td>
                                    <td>
                                        <i class="fas fa-dollar-sign"></i>
                                        <?php echo number_format($producto['total'], 2); ?>
                                    </td>
                                    <td>
                                        <label class="switch">
                                            <input type="checkbox" 
                                                   <?php echo ($producto['recibido'] == 1) ? 'checked' : ''; ?> 
                                                   disabled>
                                            <span class="slider"></span>
                                        </label>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>