<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "usuario";
$password = "contraseña";
$dbname = "comerczldra";

// Crear la conexión
$conexion = new mysqli($servidor, $usuario, $password, $baseDatos);

// Verificar si hubo errores en la conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Consulta para obtener los registros
$query = "SELECT usuario, unidad_productiva, fecha_hora FROM registros";
$resultado = $conexion->query($query);

// Comprobar si hay resultados y mostrarlos
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($fila['usuario']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['unidad_productiva']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['fecha_hora']) . "</td>";
        echo '<td class="checkbox"><input type="checkbox" class="checkbox-input"></td>';
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>No hay registros</td></tr>";
}

// Cerrar la conexión
$conexion->close();
?>