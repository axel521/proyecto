<?php
$conn = new mysqli("localhost", "usuario", "contraseña", "comerczldra");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = $_POST["codigo"];
    $fecha = $_POST["fecha"];
    $producto = $_POST["producto"];
    $unit = $_POST["unit"];
    $cantidad = $_POST["cantidad"];
    $precio_unit = $_POST["precio_unit"];

    $sql = "INSERT INTO ventas (codigo, fecha, producto, unit, cantidad, precio_unit) 
            VALUES ('$codigo', '$fecha', '$producto', '$unit', '$cantidad', '$precio_unit')";

    if ($conn->query($sql) === TRUE) {
        echo "Venta registrada exitosamente";
    } else {
        echo "Error: " . $conn->error;
    }
}
$conn->close();
?>

