document.addEventListener('DOMContentLoaded', function() {
    // Función para alternar la visibilidad del dropdown
    function toggleDropdown() {
        var dropdown = document.getElementById("dropdown");
        dropdown.classList.toggle("show"); // Alterna la clase 'show' para mostrar/ocultar
    }

    // Añade el evento al botón de dropdown
    var dropdownButton = document.querySelector('.dropdown-btn');
    if (dropdownButton) {
        dropdownButton.addEventListener('click', toggleDropdown);
    }

    // Cierra el dropdown si el usuario hace clic fuera de él
    window.onclick = function(event) {
        if (!event.target.matches('.dropdown-btn') && !event.target.closest('.unidades')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                openDropdown.classList.remove("show"); // Remueve la clase 'show' para ocultar el dropdown
            }
        }
    };
});
