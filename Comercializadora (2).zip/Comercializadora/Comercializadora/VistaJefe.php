<?php
// Conexión a la base de datos
$conexion = new mysqli("localhost", "usuario", "contraseña", "comerczldra");

// Verifica si la conexión fue exitosa
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Consulta para obtener todos los usuarios
$query = "SELECT id, nombre FROM usuarios";
$resultado = $conexion->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Ventas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="sidebar">
        <img src="sena-logo.png" alt="Logo SENA" class="logo">
        <ul>
            <li class="active">Recibidos</li>
            <li>Reportes</li>
            <li>Ventas</li>
        </ul>
    </div>
    <div class="content">
        <header>
            <span class="user-info">Usuario: (Nombre)</span>
            <div class="unidades">
                UNIDADES
                <select id="unidadSelect" onchange="actualizarNombreUnidad()">
                    <option value="">Selecciona</option>
                    <option value="Ganadería">Ganadería</option>
                    <option value="Ovinos">Ovinos</option>
                    <option value="Porcinos">Porcinos</option>
                    <option value="Aves">Aves</option>
                    <option value="Caprinos">Caprinos</option>
                    <option value="Conejos">Conejos</option>
                    <option value="Agricultura">Agricultura</option>
                    <option value="Recursos Naturales">Recursos Naturales</option>
                    <option value="Tecnología">Tecnología</option>
                </select>
            </div>
            
            <div class="main-section">
                <button id="unidadButton" class="unit-register-btn">REGISTRO UNIDAD (Nombre Unidad)</button>
            </div>
        </header>
        <div class="main-section">
            <button class="unit-register-btn">REGISTRO UNIDAD </button>
            <div class="form-section">
                <div class="venta-info">
                    <label>CÓDIGO</label>
                    <input type="text" id="codigoVenta" readonly>

                    <label>FECHA</label>
                    <input type="date">

                    <label>ENTREGADO A</label>
                    <select name="entregado_a">
                        <?php
                        // Conexión a la base de datos
                        $conn = new mysqli("localhost", "usuario", "contraseña", "base_de_datos");

                        if ($conn->connect_error) {
                            die("Conexión fallida: " . $conn->connect_error);
                        }

                        // Consulta para obtener los usuarios
                        $sql = "SELECT id, nombre FROM usuarios";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Mostrar cada usuario como opción
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No hay usuarios registrados</option>";
                        }

                        $conn->close();
                        ?>
                    </select>

                    <label>RECIBIDO DE</label>
                    <select name="recibido_de">
                        <?php
                        // Conexión a la base de datos
                        $conn = new mysqli("localhost", "usuario", "contraseña", "base_de_datos");

                        if ($conn->connect_error) {
                            die("Conexión fallida: " . $conn->connect_error);
                        }

                        // Consulta para obtener los usuarios
                        $sql = "SELECT id, nombre FROM usuarios";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Mostrar cada usuario como opción
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No hay usuarios registrados</option>";
                        }

                        $conn->close();
                        ?>
                    </select>

                    <label>PRODUCTO</label>
                    <input type="text">

                    <label>UNIT</label>
                    <select id="unit">
                        <option value="">Selecciona</option>
                        <option value="kg">kg</option>
                        <option value="litro">litro</option>
                    </select>

                    <label>CANTIDAD</label>
                    <input type="number" id="cantidad" oninput="calcularValor()">

                    <label>P/UNIT</label>
                    <input type="number" id="precioUnitario" oninput="calcularValor()">

                    <label>VALORES</label>
                    <input type="text" id="valores" readonly>

                    <button class="clear-btn">Limpiar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Resto del código JavaScript aquí... -->

</body>
</html>
